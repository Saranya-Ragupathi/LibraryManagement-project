# LibraryManagement-project
Approach: Implement the below feature in your application. 
 Student Registration. able to login to search book in the library
 Book Management: Add a new book, delete a book, update a book's details,
 and search a book.
 Allow students a maximum of 15 days to borrow the book. If the book is not returned within 15 days, calculate the fine. One day equals ten rupees. 
 Limit each pupil to three books. 
 Enable book searches by author, title, and category. 
 Registration of librarians 
 Any Librarian may issue books to any student.
